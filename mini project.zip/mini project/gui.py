import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
from PIL import Image, ImageTk

# Load the dataset
csv_file = "large_combined_products_reviews.csv"
df = pd.read_csv(csv_file)

# Function to update the products list based on the selected category
def update_products_list(event):
    selected_category = category_combobox.get()
    products = df[df['Category'] == selected_category]['Product Name'].tolist()
    product_listbox.delete(0, tk.END)  # Clear the listbox
    for product in products:
        product_listbox.insert(tk.END, product)

# Function to update the product details based on the selected product
def update_product_details(event):
    selected_product = product_listbox.get(tk.ANCHOR)  # Get the selected product
    if not selected_product:  # If no product is selected, do nothing
        return
    product_data = df[df['Product Name'] == selected_product].iloc[0]
    
    # Update the labels with product details
    product_name_label.config(text=f"Product Name: {product_data['Product Name']}")
    product_category_label.config(text=f"Category: {product_data['Category']}")
    product_price_label.config(text=f"Price: {product_data['Price']}")
    product_description_label.config(text=f"Description: {product_data['Description']}")
    user_review_label.config(text=f"User Feedback: {product_data['User Feedback']}")
    compare_views_label.config(text=f"Compare Views: {product_data['Compare Views']}")

# Function to submit user feedback
def submit_feedback():
    selected_product = product_listbox.get(tk.ANCHOR)
    if not selected_product:
        messagebox.showerror("Error", "Please select a product to provide feedback.")
        return
    
    # Get the feedback
    feedback = feedback_entry.get().strip()
    if not feedback:
        messagebox.showinfo("Thank You", "Thank you for visiting!")
        return  # Do not save empty feedback

    # Append feedback to the dataset
    global df
    product_index = df[df['Product Name'] == selected_product].index[0]
    existing_feedback = df.at[product_index, "User Feedback"]
    updated_feedback = feedback if not existing_feedback else f"{existing_feedback} | {feedback}"
    df.at[product_index, "User Feedback"] = updated_feedback
    
    # Update Compare Views column
    compare_views = f"Previous: {existing_feedback if existing_feedback else 'None'} | New: {feedback}"
    df.at[product_index, "Compare Views"] = compare_views

    # Save the updated DataFrame
    df.to_csv(csv_file, index=False)
    
    # Update user feedback label
    user_review_label.config(text=f"User Feedback: {updated_feedback}")
    compare_views_label.config(text=f"Compare Views: {compare_views}")
    feedback_entry.delete(0, tk.END)  # Clear feedback entry
    messagebox.showinfo("Success", "Feedback submitted successfully!")

# Create the main window
root = tk.Tk()
root.title("Tech Review System")
root.geometry("900x950")

# Add main heading
title_label = tk.Label(root, text="Tech Review System", font=("Helvetica", 18, "bold"), pady=10)
title_label.pack()

# Add logos to the GUI
logo_frame = tk.Frame(root)
logo_frame.pack(pady=10)

# Load and display logos
logo1_image = Image.open("nri logo.jpg").resize((100, 100))  # Adjust path and size
logo2_image = Image.open("it logo.png").resize((100, 100))  # Adjust path and size
logo1 = ImageTk.PhotoImage(logo1_image)
logo2 = ImageTk.PhotoImage(logo2_image)
logo1_label = tk.Label(logo_frame, image=logo1)
logo2_label = tk.Label(logo_frame, image=logo2)
logo1_label.pack(side=tk.LEFT, padx=10)
logo2_label.pack(side=tk.RIGHT, padx=10)

# Label for category selection
category_label = tk.Label(root, text="Select Category", font=("Arial", 14))
category_label.pack(pady=10)

# Combobox to select category
categories = df['Category'].unique().tolist()
category_combobox = ttk.Combobox(root, values=categories, width=50)
category_combobox.bind("<<ComboboxSelected>>", update_products_list)
category_combobox.pack(pady=10)

# Listbox to display products in the selected category
product_listbox = tk.Listbox(root, width=50, height=5)
product_listbox.bind("<<ListboxSelect>>", update_product_details)
product_listbox.pack(pady=10)

# Labels for displaying product details
product_name_label = tk.Label(root, text="Product Name: ", font=("Arial", 12))
product_name_label.pack(pady=5)

product_category_label = tk.Label(root, text="Category: ", font=("Arial", 12))
product_category_label.pack(pady=5)

product_price_label = tk.Label(root, text="Price: ", font=("Arial", 12))
product_price_label.pack(pady=5)

product_description_label = tk.Label(root, text="Description: ", font=("Arial", 12), wraplength=700)
product_description_label.pack(pady=5)

user_review_label = tk.Label(root, text="User Feedback: ", font=("Arial", 12), wraplength=700)
user_review_label.pack(pady=5)

compare_views_label = tk.Label(root, text="Compare Views: ", font=("Arial", 12), wraplength=700)
compare_views_label.pack(pady=5)

# Entry for user feedback
feedback_label = tk.Label(root, text="Your Feedback (Optional):", font=("Arial", 12))
feedback_label.pack(pady=10)

feedback_entry = tk.Entry(root, width=60)
feedback_entry.pack(pady=5)

# Submit feedback button
submit_button = tk.Button(root, text="Submit Feedback", command=submit_feedback, font=("Arial", 12),bg="#ff00ff")
submit_button.pack(pady=10)

# Start the GUI loop
root.mainloop()

import pandas as pd
import random

# Step 1: Define categories, products, and descriptions
categories = {
    "Phones": ["iPhone 15", "Moto G73", "OnePlus 12", "Realme GT 5", "Redmi Note 13", "JioBharat Phone", "iQOO Neo 7"],
    "Laptops": ["Apple MacBook Air", "Dell XPS 13", "HP Pavilion", "Asus ROG Zephyrus", "Lenovo IdeaPad", "Acer Aspire 7"],
    "Televisions": ["Samsung QLED", "Sony Bravia", "LG OLED", "OnePlus TV", "Realme Smart TV"],
    "Refrigerators": ["Samsung Double Door", "LG InstaView", "Whirlpool Frost-Free", "Godrej EdgePro"],
    "Washing Machines": ["Bosch Front Load", "LG TwinWash", "Whirlpool Stainwash", "Samsung EcoBubble"],
    "Air Conditioners": ["Daikin Inverter AC", "LG DualCool", "Samsung WindFree", "Voltas Split AC", "Blue Star AC"],
    "Gaming Consoles": ["PlayStation 5", "Xbox Series X", "Nintendo Switch OLED"],
    "Smart Watches": ["Samsung Galaxy Watch 5", "Garmin Forerunner 945", "Fossil Gen 6"],
}

descriptions = {
    "Phones": "Feature-packed phone with fast processor, excellent camera, and long battery life.",
    "Laptops": "High-performance laptop suitable for gaming, productivity, and everyday use.",
    "Televisions": "Smart TV with 4K resolution, vibrant colors, and immersive sound.",
    "Refrigerators": "Energy-efficient refrigerator with spacious compartments and advanced cooling technology.",
    "Washing Machines": "Efficient washing machine with quick wash cycles and silent operation.",
    "Air Conditioners": "Powerful air conditioner with energy-saving inverter technology.",
    "Gaming Consoles": "High-performance gaming consoles for an immersive gaming experience.",
    "Smart Watches": "Stylish and feature-rich smartwatches for fitness tracking and smartphone integration.",
}

reviews = [
    "Excellent product! Works perfectly as described.",
    "Amazing product! Exceeded my expectations.",
    "Good value for money, but could be better.",
    "Product is decent, but could use some improvements.",
    "Not happy with the build quality. Needs improvement.",
    "The performance is top-notch, but the price is a bit high.",
    "Delivery was quick, and the product exceeded my expectations."
]

# Step 2: Generate dataset
def generate_dataset(categories, descriptions, reviews):
    dataset = []
    for category, products in categories.items():
        for product in products:
            price_min = random.randint(1000, 50000)
            price_max = price_min + random.randint(1000, 50000)
            dataset.append({
                "Product Name": product,
                "Category": category,
                "Description": descriptions[category],
                "Price": f"₹{price_min:,} - ₹{price_max:,}",
                "User Feedback": "\n \n \n ".join(random.sample(reviews, 3)),  # Initialize with three random reviews
                "Compare Views": ""
            })
    return pd.DataFrame(dataset)

# Step 3: Save the dataset
dataset = generate_dataset(categories, descriptions, reviews)
dataset.to_csv("large_combined_products_reviews.csv", index=False)
print("\nDataset saved as 'large_combined_products_reviews.csv'")
